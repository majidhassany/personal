from django.apps import AppConfig


class MyprofileConfig(AppConfig):
    name = 'myprofile'
