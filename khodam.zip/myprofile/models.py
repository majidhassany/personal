from django.db import models

# Create your models here.

class Education(models.Model):
    date_from = models.DateField()
    date_to = models.DateField()
    university = models.CharField(max_length=200)
    field = models.CharField(max_length=200)
    level = models.CharField(max_length=100)
    description = models.TextField(max_length=400,null=True)


    def __str__(self):
        return self.field


class Experience(models.Model):
    date_from = models.DateField()
    date_to = models.DateField()
    company = models.CharField(max_length=200)
    title = models.CharField(max_length=200)
    description = models.TextField(max_length=400,null=True)


    def __str__(self):
        return self.title


class Skill(models.Model):
    title = models.CharField(max_length=200)
    level = models.PositiveIntegerField()

    def __str__(self):
        return self.title


class Skill2(models.Model):
    title = models.CharField(max_length=200)
    level = models.PositiveIntegerField()

    def __str__(self):
        return self.title


class Service(models.Model):
    title = models.CharField(max_length=300)
    image = models.ImageField(upload_to='products/%Y/%m/%d/')
    description = models.TextField(max_length=500)

    def __str__(self):
        return self.title


class Product(models.Model):
    name = models.CharField(max_length=100)
    price = models.PositiveIntegerField()
    period = models.CharField(max_length=100)
    description = models.TextField(max_length=1000)

    def __str__(self):
        return self.name


class Customer(models.Model):
    title = models.CharField(max_length=200)
    

    def __str__(self):
        self.title

    
class About(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone = models.CharField(max_length=12)
    email = models.EmailField()
    city = models.CharField(max_length=100)
    address = models.CharField(max_length=200)
    birth_date = models.DateField()
    description = models.TextField(max_length=1000)
    image = models.ImageField()

    def __str__(self):
        return self.first_name + self.last_name