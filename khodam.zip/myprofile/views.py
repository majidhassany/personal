from django.shortcuts import render, redirect
from .models import Education, Experience, Skill, Skill2, Service, Product, About
from django.contrib import messages
from django.core.mail import send_mail


def home(request):
    education = Education.objects.all()
    experience = Experience.objects.all()
    skill = Skill.objects.all()
    skill2 = Skill2.objects.all()
    service = Service.objects.all()
    product = Product.objects.all()
    me = About.objects.first()
    return render(request,'index.html',{'education':education,'experience':experience,'skill':skill,'skill2':skill2,'service':service,'product':product,'me':me})


def contact(request):
    send_mail = (
        title ,
        message,
        'info@majidhassany.ir',
        'majidhassany@gmail.com'
    )
    messages.success(request, 'پیام شما با موفقیت ارسال گردید', 'success')
    return redirect(home)