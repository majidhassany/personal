from django.contrib import admin
from .models import Education, Experience, Skill, Product, About,Service


admin.site.register(Education)
admin.site.register(Experience)
admin.site.register(Skill)
admin.site.register(About)
admin.site.register(Product)
admin.site.register(Service)